package tduffy.dotsmasherwear;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

import java.util.Random;

/**
 * Created by tduffy on 9/1/15.
 */
public class DotSmasherCanvas extends View implements OnTouchListener{
    private int dotX;
    private int dotY;
    private int score;
    public DotSmasherCanvas(Context context){
        super(context);
        moveDot();
        setOnTouchListener(this);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event){
        if(detectHit((int)event.getX(),(int)event.getY())){
            score++;
            invalidate();
        }
        return false;
    }

    public int getDotX() {
        return dotX;
    }

    public void setDotX(int dotX) {
        this.dotX = dotX;
    }

    public int getDotY() {
        return dotY;
    }

    public void setDotY(int dotY) {
        this.dotY = dotY;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    protected void moveDot(){
        Random generator = new Random();
        generator.setSeed(System.currentTimeMillis());
        int w = getWidth() - 20;
        int h = getHeight() - 40;
        float f = generator.nextFloat();
        dotX = (int)(f*w)%w;
        f = generator.nextFloat();
        dotY = (int)(f*h)%h;
    }
    protected boolean detectHit(int x, int y){
        if((x>=dotX&&x<=dotX+64) && (y>=dotY&&y<=dotY+64)){
            return true;
        }
        return false;
    }
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.BLACK);
        Paint paint = new Paint();
        paint.setColor(Color.RED);
        canvas.drawRect(dotX, dotY, dotX + 64, dotY + 64, paint);
        paint.setTextSize(32.0f);
        canvas.drawText("Score: " + score, 20, 30, paint);
    }
}
