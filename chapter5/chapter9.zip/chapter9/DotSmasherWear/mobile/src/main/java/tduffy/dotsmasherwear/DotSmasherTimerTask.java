package tduffy.dotsmasherwear;

import java.util.TimerTask;

/**
 * Created by tduffy on 9/1/15.
 */
public class DotSmasherTimerTask extends TimerTask {
    DotSmasherCanvas canvas;

    public DotSmasherTimerTask(DotSmasherCanvas canvas){
        this.canvas = canvas;
    }

    @Override
    public void run() {
        canvas.moveDot();
        canvas.postInvalidate();
    }
}
