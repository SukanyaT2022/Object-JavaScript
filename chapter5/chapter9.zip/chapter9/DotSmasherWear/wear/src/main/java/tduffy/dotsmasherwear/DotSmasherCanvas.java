package tduffy.dotsmasherwear;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.WindowInsets;

import java.util.Random;

/**
 * Created by tduffy on 11/20/15.
 */
public class DotSmasherCanvas extends View implements OnTouchListener, OnApplyWindowInsetsListener {
    private int dotX;
    private int dotY;
    private int score;
    private boolean isRound;
    public DotSmasherCanvas(Context context){
        super(context);
        moveDot();
        setOnTouchListener(this);
        setOnApplyWindowInsetsListener(this);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event){
        if(detectHit((int)event.getX(),(int)event.getY())){
            score++;
            invalidate();
        }
        return false;
    }

    public int getDotX() {
        return dotX;
    }

    public void setDotX(int dotX) {
        this.dotX = dotX;
    }

    public int getDotY() {
        return dotY;
    }

    public void setDotY(int dotY) {
        this.dotY = dotY;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    protected void moveDot(){
        Random generator = new Random();
        generator.setSeed(System.currentTimeMillis());
        int w = getWidth()-24;
        int h = getHeight()-24;
        float f = generator.nextFloat();
        dotX = (int)(f*w)%w;
        f = generator.nextFloat();
        dotY = (int)(f*h)%h;
    }
    protected boolean detectHit(int x, int y){
        if((x>=dotX&&x<=dotX+24) && (y>=dotY&&y<=dotY+24)){
            return true;
        }
        return false;
    }
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.BLACK);
        Paint paint = new Paint();
        paint.setColor(Color.RED);
        canvas.drawRect(dotX, dotY, dotX + 24, dotY + 24, paint);
        paint.setTextSize(16.0f);
        paint.setColor(Color.WHITE);
        if (isRound)
            canvas.drawText("Score: " + score, 70, 40, paint);
        else
            canvas.drawText("Score: " + score, 20, 30, paint);
    }
    @Override
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        if(windowInsets.isRound())
            isRound = true;
        else
            isRound = false;
        return windowInsets;
    }
}
