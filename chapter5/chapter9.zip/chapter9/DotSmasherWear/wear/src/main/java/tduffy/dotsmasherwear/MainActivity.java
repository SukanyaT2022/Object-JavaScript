package tduffy.dotsmasherwear;

import android.app.Activity;
import android.os.Bundle;
import android.support.wearable.view.WatchViewStub;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.Timer;

public class MainActivity extends Activity {

    //private TextView mTextView;
    ListView lstView;
    private Timer timer;
    private DotSmasherCanvas canvas;
    private DotSmasherTimerTask task;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final WatchViewStub stub = (WatchViewStub) findViewById(R.id.watch_view_stub);
        stub.setOnLayoutInflatedListener(new WatchViewStub.OnLayoutInflatedListener() {
            @Override
            public void onLayoutInflated(WatchViewStub layoutStub) {
                //mTextView = (TextView) stub.findViewById(R.id.text);
                lstView = (ListView) findViewById(R.id.listView);
                //Values to show in ListView
                String[] listValues = new String[]{"New Game", "Quit",};
                // Define a new Adapter to populate list view
                // First parameter - Context - get it from the stub
                // Second parameter - Layout for the row
                // Third parameter - ID of the TextView to which the data is written
                // Fourth - the Array of data
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(stub.getContext(), android.R.layout.simple_list_item_1, android.R.id.text1, listValues);
                // Assign adapter to ListView
                lstView.setAdapter(adapter);
                // ListView Item Click Listener
                lstView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        switch (position) {
                            case 0:
                                canvas = new DotSmasherCanvas(stub.getContext());
                                timer= new Timer();
                                task = new DotSmasherTimerTask(canvas);
                                timer.schedule(task, 0, 1500);
                                setContentView(canvas);
                                canvas.requestApplyInsets();
                                newGame();
                                break;
                            case 1:
                                quit();
                                break;
                            default:
                                quit();
                        }
                    }

                });
            }
        });

    }

    private void newGame() {

        canvas.setScore(0);
    }

    private void quit(){
        timer.cancel();
        timer = null;
        task = null;
        canvas = null;
        finish();
    }
}
