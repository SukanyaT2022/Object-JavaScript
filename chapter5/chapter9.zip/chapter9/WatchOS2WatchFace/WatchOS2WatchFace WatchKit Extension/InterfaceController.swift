//
//  InterfaceController.swift
//  WatchOS2WatchFace WatchKit Extension
//
//  Created by Thomas Duffy on 11/27/15.
//  Copyright © 2015 Thomas Duffy. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var util:WKInterfaceDate!
    @IBOutlet var hours:WKInterfaceLabel!
    @IBOutlet var minutes:WKInterfaceLabel!
    @IBOutlet var seconds:WKInterfaceLabel!
    var timer : NSTimer!
    
    func setTime(t:NSTimer){
        let date = NSDate();
        let calendar = NSCalendar.currentCalendar();
        var components = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Hour), fromDate: date);
        let hour = (components.hour)%12; //remove %12 for 24 hour clock
        hours.setText(String(hour));
        components = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Minute), fromDate: date);
        let minute = components.minute;
        minutes.setText(String(minute));
        components = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Second), fromDate: date);
        let second = components.second;
        seconds.setText(String(second));
    }
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        
        timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("setTime:"), userInfo: nil, repeats: true);
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
