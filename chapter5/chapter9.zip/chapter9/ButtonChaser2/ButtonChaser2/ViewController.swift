//
//  ViewController.swift
//  ButtonChaser2
//
//  Created by Thomas Duffy on 9/29/15.
//  Copyright © 2015 Thomas Duffy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var button:UIButton!
    @IBOutlet var scoreLabel:UILabel!
    var score = 0;
    var timer : NSTimer!
    
    @IBAction func processHit(sender:AnyObject){
        score += 1;
        scoreLabel.text = "Score: " + String(score);
    }
    
    func moveButton(t:NSTimer){
        let aWidth = self.view.bounds.size.width;
        let aHeight = self.view.bounds.size.height;
        let btnX = random() % (Int)(aWidth-60);
        let btnY = random() % (Int)(aHeight-60);
        button.frame = CGRectMake(CGFloat(btnX), CGFloat(btnY), 30.0, 30.0);
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        srandom(arc4random());
        timer = NSTimer.scheduledTimerWithTimeInterval(1.5, target: self, selector: Selector("moveButton:"), userInfo: nil, repeats: true);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

