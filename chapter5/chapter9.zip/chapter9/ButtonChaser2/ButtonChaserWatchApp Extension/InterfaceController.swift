//
//  InterfaceController.swift
//  ButtonChaserWatchApp Extension
//
//  Created by Thomas Duffy on 11/25/15.
//  Copyright © 2015 Thomas Duffy. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var button:WKInterfaceButton!
    @IBOutlet var scoreLabel:WKInterfaceLabel!
    var score = 0;
    var timer : NSTimer!
    
    @IBAction func processHit(sender:AnyObject){
        score += 1;
        scoreLabel.setText("Score: " + String(score));
    }
    
    func moveButton(t:NSTimer){
        //create random number between 0 and 3
        let btnX = Int(arc4random_uniform(3));
        var hAlign: WKInterfaceObjectHorizontalAlignment = WKInterfaceObjectHorizontalAlignment.Left;
        //assign a horizontal alignment
        if btnX == 0{
            hAlign = WKInterfaceObjectHorizontalAlignment.Left;
        }else if btnX == 1{
            hAlign = WKInterfaceObjectHorizontalAlignment.Center;
        }else if btnX == 2{
            hAlign = WKInterfaceObjectHorizontalAlignment.Right;
        }
        //create 2nd random number for vertical alignment
        let btnY = Int(arc4random_uniform(3));
        var vAlign: WKInterfaceObjectVerticalAlignment = WKInterfaceObjectVerticalAlignment.Top;
        //assign a vertical alignment
        if btnY == 0{
            vAlign = WKInterfaceObjectVerticalAlignment.Top;
        }else if btnY == 1{
            vAlign = WKInterfaceObjectVerticalAlignment.Center;
        }else if btnY == 2{
            vAlign = WKInterfaceObjectVerticalAlignment.Bottom;
        }
        button.setHorizontalAlignment(hAlign);
        button.setVerticalAlignment(vAlign);
    }
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)

        // Configure interface objects here.
        //get score from context dictionary
        
        if let dict: [String: Int] = context as? [String: Int] {
            self.score = dict["score"]!;
            scoreLabel.setText("Score: " + String(score));
        }
        srandom(arc4random());
        timer = NSTimer.scheduledTimerWithTimeInterval(1.5, target: self, selector: Selector("moveButton:"), userInfo: nil, repeats: true);
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
