/*
 * Copyright (C) 2014 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package tduffy.customwatchface;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.res.ResourcesCompat;
import android.support.wearable.watchface.CanvasWatchFaceService;
import android.support.wearable.watchface.WatchFaceStyle;
import android.text.format.Time;
import android.view.SurfaceHolder;

import java.lang.ref.WeakReference;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

/**
 * Analog watch face with a ticking second hand. In ambient mode, the second hand isn't shown. On
 * devices with low-bit ambient mode, the hands are drawn without anti-aliasing in ambient mode.
 */
public class MyWatchFace extends CanvasWatchFaceService {
    /**
     * Update rate in milliseconds for interactive mode. We update once a second to advance the
     * second hand.
     */
    private static final long INTERACTIVE_UPDATE_RATE_MS = TimeUnit.SECONDS.toMillis(1);

    /**
     * Handler message id for updating the time periodically in interactive mode.
     */
    private static final int MSG_UPDATE_TIME = 0;

    @Override
    public Engine onCreateEngine() {
        return new Engine();
    }

    private static class EngineHandler extends Handler {
        private final WeakReference<MyWatchFace.Engine> mWeakReference;

        public EngineHandler(MyWatchFace.Engine reference) {
            mWeakReference = new WeakReference<>(reference);
        }

        @Override
        public void handleMessage(Message msg) {
            MyWatchFace.Engine engine = mWeakReference.get();
            if (engine != null) {
                switch (msg.what) {
                    case MSG_UPDATE_TIME:
                        engine.handleUpdateTimeMessage();
                        break;
                }
            }
        }
    }
//Engine is the class that handles WatchFace life cycle events
    private class Engine extends CanvasWatchFaceService.Engine {
        final Handler mUpdateTimeHandler = new EngineHandler(this);
        boolean mRegisteredTimeZoneReceiver = false;
        Paint mBackgroundPaint;
        Paint mHandPaint;
        boolean mAmbient;

    //1. Add instance variables for background bitmaps
        Bitmap mBackgroundBitmap;
        Bitmap mBackgroundScaledBitmap;
        Bitmap mAmbientBackgroundBitmap;
        Bitmap mAmbientBackgroundScaledBitmap;

    //2. Change mTime to Calendar instance - Time class is deprecated as of API 22
        //Time mTime;
        Calendar mTime;

    //3. Change mTime method calls to Calendar methods throughout class
    //4. Get Calendar instance in onCreate()

    //5. Add instance variables for date display and battery level
        String dayName;
        int day;
        int dayNum;
        int batteryLevel;
        final BroadcastReceiver mTimeZoneReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                //Change to Calendar methods
                /*
                mTime.clear(TimeZone.getDefault().getID());
                mTime.setToNow();
                */
                mTime.clear(Calendar.ZONE_OFFSET);
                mTime.setTimeInMillis(System.currentTimeMillis());
            }
        };

    //6. Add the Broadcast Receiver to receive battery status
        final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                batteryLevel = intent.getIntExtra("level",100);
            }
        };
        boolean registeredBatteryReceiver = false;
        /**
         * Whether the display supports fewer bits for each color in ambient mode. When true, we
         * disable anti-aliasing in ambient mode.
         */
        boolean mLowBitAmbient;

    //7. Initialize as much data as possible in onCreate()
    //Remember to add active.png and ambient.png to res/drawable.
        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);

            setWatchFaceStyle(new WatchFaceStyle.Builder(MyWatchFace.this)
                    .setCardPeekMode(WatchFaceStyle.PEEK_MODE_SHORT)
                    .setBackgroundVisibility(WatchFaceStyle.BACKGROUND_VISIBILITY_INTERRUPTIVE)
                    .setShowSystemUiTime(false)
                    .build());

            Resources resources = MyWatchFace.this.getResources();
            //Paints background color
            mBackgroundPaint = new Paint();

        //8. setColor(int) deprecated.  Supply color directly instead of from res/values/colors.xml
            //mBackgroundPaint.setColor(resources.getColor(R.color.background));
            mBackgroundPaint.setColor(Color.BLACK);

        //9. Initialize background images
            //Active watchface background bitmap
            Drawable backgroundDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.active, null);
            mBackgroundBitmap = ((BitmapDrawable) backgroundDrawable).getBitmap();

            //Ambient watchface background bitmap
            Drawable ambientBackgroundDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.ambient, null);
            mAmbientBackgroundBitmap = ((BitmapDrawable) ambientBackgroundDrawable).getBitmap();

            mHandPaint = new Paint();
            //setColor(int) deprecated - see 8 above
            mHandPaint.setColor(Color.BLACK);
            mHandPaint.setStrokeWidth(resources.getDimension(R.dimen.analog_hand_stroke));
            mHandPaint.setAntiAlias(true);
            mHandPaint.setStrokeCap(Paint.Cap.ROUND);

        //4. Get Calendar Instance
            //mTime = new Time();
            mTime = Calendar.getInstance();
        }

        @Override
        public void onDestroy() {
            mUpdateTimeHandler.removeMessages(MSG_UPDATE_TIME);
            super.onDestroy();
        }

        @Override
        public void onPropertiesChanged(Bundle properties) {
            super.onPropertiesChanged(properties);
            mLowBitAmbient = properties.getBoolean(PROPERTY_LOW_BIT_AMBIENT, false);
        }

        @Override
        public void onTimeTick() {
            super.onTimeTick();
            invalidate();
        }

        @Override
        public void onAmbientModeChanged(boolean inAmbientMode) {
            super.onAmbientModeChanged(inAmbientMode);
            if (mAmbient != inAmbientMode) {
                mAmbient = inAmbientMode;
                if (mLowBitAmbient) {
                    mHandPaint.setAntiAlias(!inAmbientMode);
                }
                invalidate();
            }

            // Whether the timer should be running depends on whether we're visible (as well as
            // whether we're in ambient mode), so we may need to start or stop the timer.
            updateTimer();
        }

    //10. onDraw() called each tick. Draw all graphics here
        @Override
        public void onDraw(Canvas canvas, Rect bounds) {
            //Change to Calendar method
            //mTime.setToNow();
            mTime.setTimeInMillis(System.currentTimeMillis());

            // Draw the background.
            if (isInAmbientMode()) {
                canvas.drawColor(Color.BLACK);
            } else {
                canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), mBackgroundPaint);
            }

        //11. Create the background images, scaled to fit display
            int width = bounds.width();
            int height = bounds.height();
            // Active Background, scaled to fit.
            if (mBackgroundScaledBitmap == null
                    || mBackgroundScaledBitmap.getWidth() != width
                    || mBackgroundScaledBitmap.getHeight() != height) {
                mBackgroundScaledBitmap = Bitmap.createScaledBitmap(mBackgroundBitmap,
                        width, height, true /* filter */);
            }

            //Ambient Background scaled to fit
            if (mAmbientBackgroundScaledBitmap == null
                    || mAmbientBackgroundScaledBitmap.getWidth() != width
                    || mAmbientBackgroundScaledBitmap.getHeight() != height) {
                mAmbientBackgroundScaledBitmap = Bitmap.createScaledBitmap(mAmbientBackgroundBitmap,
                        width, height, true /* filter */);
            }
            // Find the center. Ignore the window insets so that, on round watches with a
            // "chin", the watch face is centered on the entire screen, not just the usable
            // portion.
            float centerX = bounds.width() / 2f;
            float centerY = bounds.height() / 2f;

        //Use Calendar references to determine where to draw hands
            /*
            float secRot = mTime.second / 30f * (float) Math.PI;
            int minutes = mTime.minute;
            float minRot = minutes / 30f * (float) Math.PI;
            float hrRot = ((mTime.hour + (minutes / 60f)) / 6f) * (float) Math.PI;
            */
            float secRot = mTime.get(Calendar.SECOND) / 30f * (float) Math.PI;
            int minutes = mTime.get(Calendar.MINUTE);
            float minRot = minutes / 30f * (float) Math.PI;
            float hrRot = ((mTime.get(Calendar.HOUR) + (minutes / 60f)) / 6f) * (float) Math.PI;

        //12. Data for date display
            day = mTime.get(Calendar.DAY_OF_MONTH);
            dayNum = mTime.get(Calendar.DAY_OF_WEEK);
            switch (dayNum){
                case 1:
                    dayName="SUN ";
                    break;
                case 2:
                    dayName="MON ";
                    break;
                case 3:
                    dayName="TUE ";
                    break;
                case 4:
                    dayName="WED ";
                    break;
                case 5:
                    dayName="THU ";
                    break;
                case 6:
                    dayName="FRI ";
                    break;
                case 7:
                    dayName="SAT ";
                    break;
                default:
                    dayName="";
            }

        //13. Length of hours and minutes hand, coordinates for seconds dot (modified)
            float secLength = centerX - 40;
            float minLength = centerX - 60;
            float hrLength = centerX - 80;

        //14. Data for seconds dot, hands
            float secX = (float) Math.sin(secRot) * secLength;
            float secY = (float) -Math.cos(secRot) * secLength;
            float minX = (float) Math.sin(minRot) * minLength;
            float minY = (float) -Math.cos(minRot) * minLength;
            float hrX = (float) Math.sin(hrRot) * hrLength;
            float hrY = (float) -Math.cos(hrRot) * hrLength;

        //15. Draw background image.  Draw seconds dot in Active mode only.
            if (!mAmbient) {
                //Make sure hands are the right color
                mHandPaint.setColor(Color.BLACK);

                //Active - draw Active Background
                canvas.drawBitmap(mBackgroundScaledBitmap, 0, 0, null);

                //Draw seconds dot
                canvas.drawCircle(centerX + secX, centerY + secY, 4.0f, mHandPaint);
                //if you prefer a seconds hand, uncomment the following line
                //canvas.drawLine(centerX, centerY, centerX + secX, centerY + secY, mHandPaint);


            }else{
                //Make sure hands are the right color
                mHandPaint.setColor(Color.GRAY);

                //Ambient - draw Ambient Background
                canvas.drawBitmap(mAmbientBackgroundScaledBitmap, 0, 0, null);
            }

        //16. Draw hours, minutes hands
            canvas.drawLine(centerX, centerY, centerX + hrX, centerY + hrY, mHandPaint);
            canvas.drawLine(centerX, centerY, centerX + minX, centerY + minY, mHandPaint);

        //17. Draw Circle for center
            canvas.drawCircle(centerX,centerY,12.0f,mHandPaint);

        //18. Draw day and date
            float oldTextSize = mHandPaint.getTextSize();
            mHandPaint.setTextSize(20.0f);
            canvas.drawText(dayName + day, centerX + 40, centerY, mHandPaint);

        //19. Draw battery life
            canvas.drawText(batteryLevel + "%", centerX - 100, centerY, mHandPaint);

        //20. Reset Font size of painter
            mHandPaint.setTextSize(oldTextSize);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            super.onVisibilityChanged(visible);

            if (visible) {
                registerReceiver();
                //Change to Calendar methods
                /*
                // Update time zone in case it changed while we weren't visible.
                mTime.clear(TimeZone.getDefault().getID());
                mTime.setToNow();
                */
                mTime.clear(Calendar.ZONE_OFFSET);
                mTime.setTimeInMillis(System.currentTimeMillis());

            } else {
                unregisterReceiver();
            }

            // Whether the timer should be running depends on whether we're visible (as well as
            // whether we're in ambient mode), so we may need to start or stop the timer.
            updateTimer();
        }
    //21. Add battery receiver to registerReceiver() and unregisterReceiver
        private void registerReceiver() {
            if (mRegisteredTimeZoneReceiver) {
                return;
            }
            mRegisteredTimeZoneReceiver = true;
            IntentFilter filter = new IntentFilter(Intent.ACTION_TIMEZONE_CHANGED);
            MyWatchFace.this.registerReceiver(mTimeZoneReceiver, filter);

            //register battery receiver
            if(registeredBatteryReceiver){
                return;
            }
            registeredBatteryReceiver = true;
            IntentFilter batteryFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            MyWatchFace.this.registerReceiver(batteryReceiver, batteryFilter);
        }

        private void unregisterReceiver() {
            if (!mRegisteredTimeZoneReceiver) {
                return;
            }
            mRegisteredTimeZoneReceiver = false;
            MyWatchFace.this.unregisterReceiver(mTimeZoneReceiver);

            //Unregister battery receiver
            if(!registeredBatteryReceiver){
                return;
            }
            registeredBatteryReceiver = false;
            MyWatchFace.this.unregisterReceiver(batteryReceiver);
        }

        /**
         * Starts the {@link #mUpdateTimeHandler} timer if it should be running and isn't currently
         * or stops it if it shouldn't be running but currently is.
         */
        private void updateTimer() {
            mUpdateTimeHandler.removeMessages(MSG_UPDATE_TIME);
            if (shouldTimerBeRunning()) {
                mUpdateTimeHandler.sendEmptyMessage(MSG_UPDATE_TIME);
            }
        }

        /**
         * Returns whether the {@link #mUpdateTimeHandler} timer should be running. The timer should
         * only run when we're visible and in interactive mode.
         */
        private boolean shouldTimerBeRunning() {
            return isVisible() && !isInAmbientMode();
        }

        /**
         * Handle updating the time periodically in interactive mode.
         */
        private void handleUpdateTimeMessage() {
            invalidate();
            if (shouldTimerBeRunning()) {
                long timeMs = System.currentTimeMillis();
                long delayMs = INTERACTIVE_UPDATE_RATE_MS
                        - (timeMs % INTERACTIVE_UPDATE_RATE_MS);
                mUpdateTimeHandler.sendEmptyMessageDelayed(MSG_UPDATE_TIME, delayMs);
            }
        }
    }
}
